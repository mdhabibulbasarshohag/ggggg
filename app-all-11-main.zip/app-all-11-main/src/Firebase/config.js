const firebaseConfig = {
<h1>আপনার ফায়ারবেইজের ফাইলটি বসাবেন এখানে</h1>
};

export default firebaseConfig