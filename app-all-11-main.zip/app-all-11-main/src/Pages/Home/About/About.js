import React from "react";
import {Container} from "react-bootstrap";
import "./About.css";

const About = () => {
  return (
    <div>
      <Container>
        <h1>This is your extra section</h1>
      </Container>
    </div>
  );
};

export default About;
